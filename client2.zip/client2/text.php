<?php $nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = ($_POST["name"]);
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email =  $_POST["email"];
  }

  if (empty($_POST["website"])) {
    $website = "";
  } else {
    $website =  $_POST["website"];
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment =  $_POST["comment"];
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender =  $_POST["gender"];
  }
}

echo $name . $email . $comment . $website . $gender ;
?>