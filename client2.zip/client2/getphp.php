<html>
<body>

welcome <?php echo $_GET["name"]; ?> <br>
Your emial address is: <?php echo $_GET['email']; ?>
 
</body>
</html>